#include <iostream>
#include "RouteStrategy.h"
#include "WorldMap.h"
#include "PlaceDecorator.h"
#include "BiomeFactory.h"
#include "TravelState.h"

int main() {

    std::cout << "Task 3\n";
    Traveller traveller(new FootState());
    traveller.setState(new BicycleState());
    traveller.move();
    traveller.setState(new FlyState());
    traveller.setState(new FootState());
    std::cout << "Walking multiple times to test stamina...\n";
    for (int i = 0; i < 22; ++i) {
        traveller.move();
    }
    std::cout << "\n";

    std::cout << "Task 4\n";
    Trip trip(new ShortestRoute());
    trip.executeTrip("Home City", "Destination Peak");

    trip.setStrategy(new ScenicRoute());
    trip.executeTrip("Home City", "Destination Peak");
    std::cout << "\n";

    std::cout << "Task 5\n";
    Region* world = new Region("Global Map");
    Region* continent = new Region("Northern Continent");
    continent->add(new Location("Capital City"));
    continent->add(new Location("Green Valley"));
    world->add(continent);

    world->print();
    std::cout << "\n";

    std::cout << "Task 6\n";
    Place* decoratedPlace = new TollFeature(
                                new WeatherFeature(
                                    new Location("Crossroads"), "Heavy Rain"
                                ), 15.0
                            );
    decoratedPlace->print();
    delete decoratedPlace;
    std::cout << "\n";

    std::cout << "Task 7\n";
    WorldBuilder* factory = new DesertFactory();
    Terrain* terrain = factory->createTerrain();
    NPC* npc = factory->createNPC();
    Obstacle* obstacle = factory->createObstacle();

    terrain->describe();
    npc->interact();
    obstacle->encounter();

    delete terrain;
    delete npc;
    delete obstacle;
    delete factory;

    delete world;

    return 0;
}
